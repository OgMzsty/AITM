package com.example.examplemod;

import net.minecraft.block.Block;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.fml.RegistryObject;

public class AIBlocks {

    public static final RegistryObject<Block> TARDIS = register("tardis", () -> );


    public static <T extends Block> RegistryObject<T> register(T block, String name, ItemGroup group) {
        return AIRegistry.BLOCK_REGISTER.register(name, () -> block);
    }
}
